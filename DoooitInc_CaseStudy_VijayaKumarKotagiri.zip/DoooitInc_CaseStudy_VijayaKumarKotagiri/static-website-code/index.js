$(document).ready(function(){
    readData()
    submitforms();

    $('#full').click(function(){
        let title=$("#title").val();
        let description=$('#description').val();
        let completiondate=$('#completiondate').val();
        let imagename=$('#form1 #myfile').val().split('\\').pop();
        let docname=$('#form2 #myfile').val().split('\\').pop();
        let POST = 'POST';
        alert(title+" "+description+" "+completiondate+" "+imagename+" "+docname)
        $.ajax('https://gc9d9pfruf.execute-api.us-west-2.amazonaws.com/PROD/flaskapp', {
            type: 'POST',  // http method
            data: { id:Math.round(Math.random()*10000),operation:POST,tasktitle:title,desc:description,completiondate:completiondate,imagename:imagename,documentname:docname},  // data to submit
            success: function (data, status, xhr) {
                alert("uploaded Successfully")
               console.log($("#form1"))
               $( '#btn1' )[0].click()
               $( '#btn2' )[0].click()

             
            },
            error: function (jqXhr, textStatus, errorMessage) {
                    alert("failure");
            }
        });
    })
})


function submitforms(){
    console.log($('#form1')[0])
$( '#btn1' ).click(

function( e ) {
    e.preventDefault();
    let form = $('#form1')[0]
  console.log('this is getting called')
  $.ajax( {
    url: 'http://ec2-52-42-74-26.us-west-2.compute.amazonaws.com/upload-image',
    type: 'POST',
    data: new FormData( form ),
    processData: false,
    contentType: false,
    success:function(){
        console.log("file successfully uploaded")
    },
    error:function(e){
        console.log(e)
    }
  } );
  e.preventDefault();
} );
$( '#btn2' ).click( function( e ) {

    e.preventDefault();
    let form = $('#form2')[0]
  $.ajax( {
    url: 'http://ec2-52-42-74-26.us-west-2.compute.amazonaws.com/upload-image',
    type: 'POST',
    data: new FormData( form ),
    processData: false,
    contentType: false,
    success:function(){
        console.log("file successfully uploaded")
    },
    error:function(e){
        console.log(e)
    }
  } );
 
} );
}
function readData(){
    $.get("https://gc9d9pfruf.execute-api.us-west-2.amazonaws.com/PROD/flaskapp",function(data){
        let code="<ul class='list-group'>"
        for(let x in data){
           code+="<li class='list-group-item'>"
           code+="<h3>"+data[x].tasktitle+"</h3>"
           code+="<p>"+data[x].description+"</p>"
           code+="<h6>Completion Date:"+data[x].completiondate+"</h6>"
           code+="<h5> Document :: <a href='http://d285okchgua31v.cloudfront.net/"+data[x].documentname+"'>"+data[x].documentname+"</a><h5>"
           code+="<h5>Image::<h5>"+"<img src='http://d285okchgua31v.cloudfront.net/"+data[x].imagename+"'>"
           code+="</li>"
        }
        code+="</ul>"
        $("#container").html(code)
    })
}